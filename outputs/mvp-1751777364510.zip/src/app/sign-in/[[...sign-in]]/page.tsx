import React from 'react';
import { ClerkProvider, RedirectToSignIn, SignedIn, SignedOut, SignIn, SignUp } from '@clerk/clerk-react';

function SignInPage() {
  return (
    <ClerkProvider frontendApi="your-frontend-api">
      <SignedOut>
        <SignIn path="/sign-in" routing="path" />
      </SignedOut>
      <SignedIn path="/dashboard" routing="path">
        <RedirectToSignIn />
      </SignedIn>
    </ClerkProvider>
  );
}

export default SignInPage;