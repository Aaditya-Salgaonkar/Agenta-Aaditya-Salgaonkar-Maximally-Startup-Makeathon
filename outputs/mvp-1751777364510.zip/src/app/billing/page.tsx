<h1>Billing Information</h1>

<!-- If the user has an active subscription, display the current subscription info -->
<% if @subscription %>
  <p>Current Plan: <%= @subscription.plan.name %></p>
  <p>Next Billing Date: <%= @subscription.current_period_end_at.to_s(:long) %></p>
<% end %>

<!-- Link to the Stripe billing portal where the user can manage their subscription -->
<% if @subscription %>
  <%= link_to "Manage Subscription", stripe_customer_portal_url(@subscription.customer), class: "button" %>
<% else %>
  <!-- If the user doesn't have an active subscription, prompt them to subscribe -->
  <%= link_to "Subscribe Now", new_subscription_path, class: "button" %>
<% end %>