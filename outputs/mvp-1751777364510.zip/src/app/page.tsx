import { FaQuestion } from 'react-icons/fa';

const FreelanceVault = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-100">
      <header className="bg-blue-500 text-white py-16">
        <div className="container mx-auto flex flex-col items-center">
          <h1 className="text-4xl font-bold mb-4">Freelance Vault</h1>
          <p className="text-xl mb-8">A client & project management hub for freelancers with invoicing, file sharing, and progress tracking.</p>
          <button className="bg-white text-blue-500 font-bold py-2 px-4 rounded">Get Started</button>
        </div>
      </header>

      <main className="flex-grow container mx-auto px-4 py-16">
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-4">Features</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Add feature components here */}
            <Feature title="Landing Page" description="Create a professional landing page to showcase your services." />
            <Feature title="Database CRUD" description="Manage your clients and projects with ease." />
            <Feature title="Authentication" description="Securely log in and manage your account." />
            <Feature title="Payment Integration" description="Accept payments from clients and track your earnings." />
            <Feature title="Email Notifications" description="Stay updated with important notifications and alerts." />
            <Feature title="Analytics Dashboard" description="Track your progress and growth over time." />
            <Feature title="File Upload" description="Share files with clients and collaborators." />
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-4">Testimonials</h2>
          <div className="flex flex-col sm:flex-row items-center gap-8">
            {/* Add testimonial components here */}
            <Testimonial
              name="John Doe"
              title="Freelancer"
              quote="Freelance Vault has completely transformed the way I manage my clients and projects. I highly recommend it!"
            />
            <Testimonial
              name="Jane Smith"
              title="Creative Director"
              quote="As an agency, we've found Freelance Vault to be an invaluable tool for managing our freelancers and projects. It's a game-changer!"
            />
          </div>
        </section>

        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-4">FAQ</h2>
          <div className="flex flex-col gap-4">
            {/* Add FAQ components here */}
            <FAQ
              question="How do I get started with Freelance Vault?"
              answer="Simply sign up for an account and follow the onboarding process to set up your profile and start managing your clients and projects."
            />
            <FAQ
              question="Is Freelance Vault secure?"
              answer="Yes, Freelance Vault uses industry-standard security measures to protect your data and ensure your privacy."
            />
          </div>
        </section>
      </main>

      <footer className="bg-gray-200 text-gray-800 py-8">
        <div className="container mx-auto text-center">
          <p>&copy; {new Date().getFullYear()} Freelance Vault. All rights reserved.</p>
          <button className="bg-blue-500 text-white font-bold py-2 px-4 rounded ml-4">
            <FaQuestion size={16} className="inline mr-2" />
            Contact Us
          </button>
        </div>
      </footer>
    </div>
  );
};

const Feature = ({ title, description }: { title: string; description: string }) => {
  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const Testimonial = ({ name, title, quote }: { name: string; title: string; quote: string }) => {
  return (
    <div className="bg-white p-4 rounded shadow">
      <p className="text-xl font-bold mb-2">{quote}</p>
      <p className="text-gray-600">
        {name} - {title}
      </p>
    </div>
  );
};

const FAQ = ({ question, answer }: { question: string; answer: string }) => {
  return (
    <div className="bg-white p-4 rounded shadow">
      <details className="group border-l-4 border-blue-500 bg-white text-gray-900 group-focus:border-blue-700 group-focus:bg-gray-100 cursor-pointer">
        <summary className="flex items-center justify-between py-2">
          <span className="text-xl font-bold">{question}</span>
          <span className="text-xl font-bold group-focus:rotate-180 duration-200">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
              className="h-6 w-6 transform rotate-0 group-focus:-rotate-90"
            >
              <path
                fillRule="evenodd"
                d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                clipRule="evenodd"
              />
            </svg>
          </span>
        </summary>
        <p className="py-2 pl-8">{answer}</p>
      </details>
    </div>
  );
};

export default FreelanceVault;