import { useState } from 'react';

const FileUploadPage = () => {
  const [files, setFiles] = useState<FileList | null>(null);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setFiles(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFiles(e.target.files);
  };

  const handleSubmit = async () => {
    if (!files) return;

    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    // Replace with your own API endpoint
    const response = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
    });

    if (response.ok) {
      console.log('Files uploaded successfully');
      setFiles(null);
    } else {
      console.error('Failed to upload files');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <div
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className="w-64 h-64 border-2 border-dashed border-gray-400 rounded-lg flex items-center justify-center"
      >
        <input type="file" multiple onChange={handleChange} className="hidden" />
        <div>
          <svg
            className="w-16 h-16 text-gray-400"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
            />
          </svg>
          <p className="text-gray-600">Drag and drop files here or</p>
          <button
            onClick={() => document.querySelector('input[type="file"]')?.click()}
            className="bg-blue-500 text-white py-1 px-3 rounded-md hover:bg-blue-600"
          >
            Browse
          </button>
        </div>
      </div>
      <button
        onClick={handleSubmit}
        disabled={!files}
        className="bg-green-500 text-white py-1 px-3 rounded-md mt-4 hover:bg-green-600 disabled:opacity-50"
      >
        Upload
      </button>
    </div>
  );
};

export default FileUploadPage;