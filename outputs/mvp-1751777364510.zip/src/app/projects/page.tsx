import { useEffect, useState } from 'react';
import { useClerk } from '@clerk/clerk-react';
import prisma from '../lib/prisma';

export default function ProjectsPage() {
  const { userId } = useClerk();
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    if (!userId) return;

    const fetchProjects = async () => {
      const userProjects = await prisma.project.findMany({
        where: {
          userId,
        },
      });

      setProjects(userProjects);
    };

    fetchProjects();
  }, [userId]);

  return (
    <div>
      <h1>My Projects</h1>
      <ul>
        {projects.map((project) => (
          <li key={project.id}>{project.name}</li>
        ))}
      </ul>
    </div>
  );
}