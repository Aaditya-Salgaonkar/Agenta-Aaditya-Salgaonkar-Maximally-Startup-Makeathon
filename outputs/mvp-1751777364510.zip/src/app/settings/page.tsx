import { useUser } from "@clerk/clerk-react";

function SettingsPage() {
  const { user, updateUser } = useUser();

  const handleSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.target);
    const firstName = formData.get("firstName");
    const lastName = formData.get("lastName");
    const email = formData.get("email");

    await updateUser({
      firstName,
      lastName,
      email,
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="firstName">First Name:</label>
      <input type="text" name="firstName" defaultValue={user.firstName} />

      <label htmlFor="lastName">Last Name:</label>
      <input type="text" name="lastName" defaultValue={user.lastName} />

      <label htmlFor="email">Email:</label>
      <input type="email" name="email" defaultValue={user.email} />

      <button type="submit">Update Profile</button>
    </form>
  );
}

export default SettingsPage;