import nodemailer from 'nodemailer';

// Create a transporter using your email provider's SMTP information
const transporter = nodemailer.createTransport({
  host: 'smtp.example.com',
  port: 587,
  auth: {
    user: 'your-email@example.com',
    pass: 'your-email-password',
  },
});

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { to, subject, text } = req.body;

    try {
      // Send the email
      await transporter.sendMail({ to, subject, text });
      res.status(200).json({ message: 'Email sent' });
    } catch (error) {
      res.status(500).json({ message: 'Error sending email' });
    }
  } else {
    res.status(405).json({ message: 'Method not allowed' });
  }
}