module.exports = {
  mode: 'jit',
  purge: ['./pages/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        primary: '#4F46E5',
        secondary: '#2E3440',
        'light-blue': '#A5D8FF',
        'dark-blue': '#1A2027',
        'light-gray': '#E5E7EB',
        'dark-gray': '#3B4252',
      },
      boxShadow: {
        card: '0px 2px 4px rgba(0, 0, 0, 0.1)',
      },
      borderRadius: {
        md: '4px',
      },
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}