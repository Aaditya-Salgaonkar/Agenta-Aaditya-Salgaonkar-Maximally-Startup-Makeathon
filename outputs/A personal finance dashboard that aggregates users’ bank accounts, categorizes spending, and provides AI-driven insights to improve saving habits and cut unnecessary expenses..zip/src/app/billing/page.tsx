import React from 'react';
import { useHistory } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';

const stripePromise = loadStripe(process.env.REACT_APP_STRIPE_PUBLISHABLE_KEY);

const BillingPage = () => {
  const history = useHistory();

  const handleManageSubscription = async () => {
    const stripe = await stripePromise;
    const response = await fetch('/api/subscriptions/url', { method: 'POST' });
    const { url } = await response.json();
    await stripe.redirectToCheckout({ sessionId: url });
  };

  return (
    <div>
      <h1>Billing Information</h1>
      <p>Current Subscription: {/* Display current subscription info here */}</p>
      <button onClick={handleManageSubscription}>Manage Subscription</button>
    </div>
  );
};

export default BillingPage;