import { useUser } from "@clerk/clerk-react";
import { useState } from "react";

const Settings = () => {
  const { user, updateUser } = useUser();
  const [firstName, setFirstName] = useState(user.firstName);
  const [lastName, setLastName] = useState(user.lastName);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateUser({ firstName, lastName });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        First Name:
        <input
          type="text"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
        />
      </label>
      <label>
        Last Name:
        <input
          type="text"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
        />
      </label>
      <button type="submit">Update</button>
    </form>
  );
};

export default Settings;