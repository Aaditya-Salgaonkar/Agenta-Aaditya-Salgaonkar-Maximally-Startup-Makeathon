import React from 'react';

const Hero = () => {
  return (
    <section className="bg-gray-900 text-white py-20">
      <div className="container mx-auto flex flex-col items-center justify-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-5">
          Personal Finance Dashboard
        </h1>
        <p className="text-gray-300 text-xl md:text-2xl mb-10">
          Aggregate your bank accounts, categorize spending, and get AI-driven insights to improve your saving habits.
        </p>
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          Get Started
        </button>
      </div>
    </section>
  );
};

const Features = () => {
  return (
    <section className="bg-gray-100 py-12">
      <div className="container mx-auto text-center">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-10">
          Powerful Features
        </h2>
        <div className="flex flex-col md:flex-row justify-center items-center md:space-x-10 space-y-10 md:space-y-0">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-3">Database CRUD</h3>
            <p className="text-gray-600">
              Easily manage your financial data with our robust database CRUD functionality.
            </p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-3">Payment Integration</h3>
            <p className="text-gray-600">
              Seamlessly integrate with popular payment gateways for secure transactions.
            </p>
          </div>
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-3">Analytics Dashboard</h3>
            <p className="text-gray-600">
              Visualize your spending habits and track your savings progress with our intuitive analytics dashboard.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

const LandingPage: React.FC = () => {
  return (
    <div>
      <Hero />
      <Features />
      {/* Add more components for pricing, testimonials, FAQ, and CTA */}
    </div>
  );
};

export default LandingPage;