npm install --save nodemailer
npm install --save next-connect
npm install --save @types/node
npm install --save @types/react
npm install --save @types/react-dom