npx create-next-app@latest my-app --typescript
cd my-app
npm install @clerk/clerk-sdk-node @clerk/nextjs