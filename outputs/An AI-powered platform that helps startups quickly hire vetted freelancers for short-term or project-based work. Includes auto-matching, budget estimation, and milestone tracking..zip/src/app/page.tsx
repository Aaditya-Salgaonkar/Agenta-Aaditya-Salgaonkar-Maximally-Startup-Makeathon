import React from 'react';

interface Feature {
  title: string;
  description: string;
}

const features: Feature[] = [
  {
    title: 'Auto-matching',
    description:
      'Our AI-powered platform automatically matches your project with the best freelancers, saving you time and effort.',
  },
  {
    title: 'Budget Estimation',
    description:
      'Get accurate budget estimates for your projects, helping you plan and allocate resources effectively.',
  },
  {
    title: 'Milestone Tracking',
    description:
      'Easily track project milestones and ensure that your freelancers are meeting their deadlines.',
  },
];

const pricing: { title: string; price: string; description: string }[] = [
  {
    title: 'Startup',
    price: '$99/month',
    description:
      'Ideal for startups and small teams looking to hire freelancers for short-term projects.',
  },
  {
    title: 'Agency',
    price: '$299/month',
    description:
      'Perfect for agencies and larger teams that require more extensive freelancer support.',
  },
];

const testimonials: {
  quote: string;
  name: string;
  title: string;
  company: string;
}[] = [
  {
    quote:
      'This platform has revolutionized the way we hire freelancers. The AI-powered auto-matching is incredibly accurate and saves us so much time.',
    name: 'John Doe',
    title: 'Founder',
    company: 'Acme Inc.',
  },
  {
    quote:
      'The budget estimation and milestone tracking features are game-changers. We can now plan and manage projects more effectively than ever before.',
    name: 'Jane Smith',
    title: 'CEO',
    company: 'Initech',
  },
];

const faqs: { question: string; answer: string }[] = [
  {
    question: 'How does the auto-matching feature work?',
    answer:
      'Our AI-powered platform analyzes your project requirements and matches them with the skills and experience of our vetted freelancers.',
  },
  {
    question: 'Can I change my subscription plan at any time?',
    answer:
      'Yes, you can upgrade, downgrade, or cancel your subscription at any time. Simply visit the Admin Panel to make changes to your plan.',
  },
];

const CallToAction = () => {
  return (
    <div className="bg-blue-500 text-white py-4 px-6 rounded-lg shadow-md mt-8">
      <p className="text-lg font-semibold">Ready to get started?</p>
      <p className="text-sm">Sign up for our 14-day free trial today!</p>
      <button className="bg-white text-blue-500 font-semibold py-2 px-4 rounded-lg shadow-md mt-4">
        Sign Up
      </button>
    </div>
  );
};

const LandingPage = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-6">
      <div className="w-full max-w-5xl text-center">
        <h1 className="text-5xl font-bold leading-tight mb-4">
          The Future of Hiring Vetted Freelancers
        </h1>
        <p className="text-xl mb-8">
          Our AI-powered platform helps startups quickly hire vetted freelancers for
          short-term or project-based work, including auto-matching, budget
          estimation, and milestone tracking.
        </p>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <h2 className="text-3xl font-bold leading-tight mb-4">Features</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white text-gray-800 rounded-lg shadow-md p-6"
            >
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <h2 className="text-3xl font-bold leading-tight mb-4">Pricing</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {pricing.map((plan, index) => (
            <div
              key={index}
              className="bg-white text-gray-800 rounded-lg shadow-md p-6"
            >
              <h3 className="text-xl font-semibold mb-2">{plan.title}</h3>
              <p className="text-xl font-semibold mb-4">{plan.price}</p>
              <p className="text-gray-600">{plan.description}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <h2 className="text-3xl font-bold leading-tight mb-4">
          Testimonials
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-white text-gray-800 rounded-lg shadow-md p-6"
            >
              <p className="text-gray-600">{testimonial.quote}</p>
              <p className="text-sm mt-4 font-semibold">
                {testimonial.name}, {testimonial.title} - {testimonial.company}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="w-full max-w-5xl mb-12">
        <h2 className="text-3xl font-bold leading-tight mb-4">FAQ</h2>
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white text-gray-800 rounded-lg shadow-md p-6">
              <h3 className="text-xl font-semibold mb-2">{faq.question}</h3>
              <p className="text-gray-600">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>

      <CallToAction />
    </div>
  );
};

export default LandingPage;