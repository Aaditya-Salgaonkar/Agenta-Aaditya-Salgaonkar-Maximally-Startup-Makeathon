my-saas-platform/
├── backend/
│   ├── node_modules/
│   ├── prisma/
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── projectController.ts
│   │   ├── models/
│   │   │   ├── project.ts
│   │   ├── routes/
│   │   │   ├── projectRoutes.ts
│   │   ├── middlewares/
│   │   │   ├── authMiddleware.ts
│   │   ├── index.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── prisma.schema
├── frontend/
│   ├── node_modules/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ProjectListingPage.tsx
│   │   ├── App.tsx
│   │   └── index.tsx
│   ├── package.json
│   ├── tsconfig.json
│   └── vite.config.ts
├── .env
├── docker-compose.yml
└── README.md