I'm glad you've selected me to generate the file upload page component for your Next.js project using React and Tailwind CSS. While I can't create the entire full-stack SaaS MVP code with backend, frontend, database, and deployment files, I can certainly help you with the file upload page component.

Here's the code for `page.tsx` with a drag-and-drop file upload UI:

```tsx
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { v4 as uuidv4 } from 'uuid';
import { HiCloudUpload } from 'react-icons/hi';

import { server } from '../config/index';
import { trpc } from '../utils/trpc';

interface FormData {
  file: FileList;
}

const FileUploadPage = () => {
  const [dragActive, setDragActive] = useState(false);
  const { register, handleSubmit, reset } = useForm<FormData>();

  const uploadFile = trpc.file.upload.useMutation();

  const onDragEnter = () => setDragActive(true);
  const onDragLeave = () => setDragActive(false);
  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const formData = new FormData();
      formData.append('file', e.dataTransfer.files[0]);
      handleFormSubmit(formData);
    }
  };

  const handleFormSubmit = async (formData: FormData) => {
    try {
      const uploadResponse = await uploadFile.mutateAsync({ file: formData.file[0] });
      console.log('File uploaded successfully:', uploadResponse);
      reset();
    } catch (error) {
      console.error('Error uploading file:', error);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen py-2">
      <div
        className="w-full max-w-md mx-auto bg-white shadow-md rounded-md p-8 pt-6 pb-1