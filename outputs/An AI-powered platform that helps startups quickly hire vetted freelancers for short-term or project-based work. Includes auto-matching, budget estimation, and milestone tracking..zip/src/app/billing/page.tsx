const express = require('express');
const router = express.Router();
const stripe = require('stripe')('your_stripe_secret_key');

router.get('/portal', async (req, res) => {
  // Retrieve the Stripe customer ID from your database
  const customerId = req.user.stripeCustomerId;

  // Redirect to the Stripe billing portal
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: 'https://your-app-url.com/account',
  });

  res.redirect(session.url);
});

module.exports = router;