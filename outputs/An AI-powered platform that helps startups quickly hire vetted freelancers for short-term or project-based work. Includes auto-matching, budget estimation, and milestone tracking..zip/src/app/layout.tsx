import { ClerkProvider } from "@clerk/nextjs";
import { useRouter } from "next/router";
import Sidebar from "./Sidebar";

const MyApp = ({ Component, pageProps }) => {
  const router = useRouter();

  return (
    <ClerkProvider frontendApi="your-clerk-frontend-api">
      <div className="flex">
        <Sidebar path={router.pathname} />
        <Component {...pageProps} />
      </div>
    </ClerkProvider>
  );
};

export default MyApp;