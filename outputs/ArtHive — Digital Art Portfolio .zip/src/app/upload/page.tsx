typescript
// FileUploadPage.tsx

import React from 'react';
import { useDropzone } from 'react-dropzone';

interface FileDropzoneProps {
  onDrop: (files: File[]) => void;
}

interface FileDropzoneState {
  files: File[];
}

const FileDropzone: React.FC<FileDropzoneProps> = ({ onDrop }) => {
  const [files, setFiles] = React.useState<FileDropzoneState['files']>([]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: (acceptedFiles) => {
      setFiles(acceptedFiles);
      onDrop(acceptedFiles);
    },
  });

  return (
    <div
      {...getRootProps()}
      className="w-64 h-64 border-2 border-dashed border-gray-400 rounded-lg flex flex-col justify-center items-center"
    >
      <input {...getInputProps()} />
      {isDragActive ? (
        <p>Drop the files here ...</p>
      ) : (
        <p>Drag and drop some files here, or click to select files</p>
      )}
      <aside>
        {files.map((file, index) => (
          <div key={index}>
            {file.name} - {file.size} bytes
          </div>
        ))}
      </aside>
    </div>
  );
};

export default FileDropzone;