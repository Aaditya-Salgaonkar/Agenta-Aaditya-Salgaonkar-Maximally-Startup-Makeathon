typescript
// components/Hero.tsx
import React from 'react';

interface HeroProps {
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
}

const Hero = ({ title, subtitle, buttonText, buttonLink }: HeroProps) => {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto flex flex-col items-center px-4">
        <h1 className="text-5xl font-extrabold leading-none text-center sm:text-6xl md:text-7xl lg:text-8xl">
          {title}
        </h1>
        <p className="max-w-2xl mb-10 mt-6 text-center text-gray-600 md:text-lg lg:text-xl">
          {subtitle}
        </p>
        <a
          href={buttonLink}
          className="inline-block px-7 py-3 bg-blue-600 text-white font-medium text-sm leading-snug uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out"
        >
          {buttonText}
        </a>
      </div>
    </section>
  );
};

export default Hero;

// components/Features.tsx
import React from 'react';

interface FeatureProps {
  title: string;
  subtitle: string;
  image: string;
}

const Feature = ({ title, subtitle, image }: FeatureProps) => {
  return (
    <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
      <div className="grid gap-8 lg:grid-cols-3 sm:grid-cols-2">
        <div className="relative overflow-hidden transition duration-200 transform rounded shadow-xl sm:col-span-2 lg:col-span-1">
          <div className="absolute inset-0 z-10 w-full h-full bg-center bg-cover">
            <img src={image} alt="" />
          </div>
          <div className="absolute inset-0 z-20 w-full h-full bg-black opacity-50"></div>
          <div className="absolute inset-0 z-30 flex items-center justify-center w-full h-full">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white tracking-tight">
                {title}
              </h3>
              <p className="mt-2 text-white">{subtitle}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Feature;

// components/Testimonials.tsx
import React from 'react';

interface TestimonialProps {
  author: string;
  quote: string;
}

const Testimonial = ({ author, quote }: TestimonialProps) => {
  return (
    <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="lg:pr-8 lg:border-r lg:border-gray-200">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            What Our Users Say
          </h2>
          <p className="mt-4 text-gray-600">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
            eget ligula vitae nisi tincidunt dapibus. Pellentesque cursus
            ullamcorper ullamcorper.
          </p>
        </div>
        <div className="flex flex-col justify-center space-y-4 lg:pl-8">
          <blockquote>
            <p className="text-gray-900">{quote}</p>
          </blockquote>
          <cite className="not-italic">{author}</cite>
        </div>
      </div>
    </div>
  );
};

export default Testimonial;

// components/Pricing.tsx
import React from 'react';

interface PriceProps {
  title: string;
  price: string;
  features: string[];
}

const Price = ({ title, price, features }: PriceProps) => {
  return (
    <div className="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
      <div className="grid gap-8 lg:grid-cols-3 sm:grid-cols-2">
        <div className="relative overflow-hidden transition duration-200 transform rounded shadow-xl">
          <div className="absolute inset-0 z-10 w-full h-full bg-center bg-cover">
            <img src="https://source.unsplash.com/random" alt="" />
          </div>
          <div className="absolute inset-0 z-20 w-full h-full bg-black opacity-50"></div>
          <div className="absolute inset-0 z-30 flex items-center justify-center w-full h-full">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-white tracking-tight">
                {title}
              </h3>
              <p className="mt-2 text-white">{price}</p>
            </div>
          </div>
        </div>
        <div className="space-y-8">
          <div>
            <h3 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
              Standard Plan
            </h3>
            <p className="mt-4 text-gray-600">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque
              eget ligula vitae nisi tincidunt dapibus. Pellentesque cursus
              ullamcorper ullamcorper.
            </p>
          </div>
          {features.map((feature, index) => (
            <div key={index} className="flex items-center">
              <div className="bg-gray-200 rounded-full w-3 h-3"></div>
              <p className="ml-4 text-gray-900">{feature}</p>
            </div>
          ))}
          <button className="w-full px-7 py-3 bg-blue-600 text-white font-medium text-sm leading-snug uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out">
            Button
          </button>
        </div>
      </div>
    </div>
  );
};

export default Price;

// components/CTA.tsx
import React from 'react';

interface CTAProps {
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
}

const CTA = ({ title, subtitle, buttonText, buttonLink }: CTAProps) => {
  return (
    <section className="bg-white py-16">
      <div className="container mx-auto flex flex-col items-center px-4">
        <h1 className="text-5xl font-extrabold leading-none text-center sm:text-6xl md:text-7xl lg:text-8xl">
          {title}
        </h1>
        <p className="max-w-2xl mb-10 mt-6 text-center text-gray-600 md:text-lg lg:text-xl">
          {subtitle}
        </p>
        <a
          href={buttonLink}
          className="inline-block px-7 py-3 bg-blue-600 text-white font-medium text-sm leading-snug uppercase rounded shadow-md hover:bg-blue-700 hover:shadow-lg focus:bg-blue-700 focus:shadow-lg focus:outline-none focus:ring-0 active:bg-blue-800 active:shadow-lg transition duration-150 ease-in-out"
        >
          {buttonText}
        </a>
      </div>
    </section>
  );
};

export default CTA;

// pages/index.tsx
import React from 'react';
import Hero from '../components/Hero';
import Feature from '../components/Feature';
import Testimonial from '../components/Testimonial';
import Price from '../components/Price';
import CTA from '../components/CTA';

const Home: React.FC = () => {
  return (
    <div>
      <Hero
        title="Personal Branded Storefront"
        subtitle="Showcase and sell your digital art with a personalized storefront."
        buttonText="Get Started"
        buttonLink="#"
      />
      <Feature
        title="Features"
        subtitle="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget ligula vitae nisi tincidunt dapibus."
        image="https://source.unsplash.com/random"
      />
      <Testimonial
        author="John Doe"
        quote="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget ligula vitae nisi tincidunt dapibus."
      />
      <Price
        title="Standard Plan"
        price="$19.99/month"
        features={[
          'Lorem ipsum dolor sit amet',
          'Consectetur adipiscing elit',
          'Quisque eget ligula vitae nisi',
          'Tincidunt dapibus',
        ]}
      />
      <CTA
        title="Join the Creator Economy"
        subtitle="Empower your digital art career with our platform."
        buttonText="Sign Up Now"
        buttonLink="#"
      />
    </div>
  );
};

export default Home;