typescript
import React from 'react';
import { ClerkProvider } from '@clerk/clerk-react';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <ClerkProvider frontendApi="your-clerk-frontend-api">
      <div className="flex">
        <aside className="w-64 bg-gray-800 text-white p-6">Sidebar</aside>
        <main className="flex-1 p-6">{children}</main>
      </div>
    </ClerkProvider>
  );
};

export default Layout;