typescript
// types.ts

import { User, UserRole } from "@clerk/clerk-sdk-node";

export interface Project {
  id: number;
  name: string;
  description: string;
  imageUrl?: string;
  price?: number;
  userId: User["id"];
}

export interface UserWithProjects extends User {
  projects: Project[];
}

// ProjectListing.tsx

import { useEffect, useState } from "react";
import axios from "axios";
import { useUser } from "@clerk/clerk-react";
import { UserWithProjects } from "./types";

const ProjectListing = () => {
  const { user } = useUser();
  const [userWithProjects, setUserWithProjects] = useState<UserWithProjects | null>(
    null
  );

  useEffect(() => {
    if (user?.id) {
      const fetchData = async () => {
        try {
          const response = await axios.get<UserWithProjects>(
            `/api/users/${user.id}/projects`
          );
          setUserWithProjects(response.data);
        } catch (error) {
          console.error("Error fetching user with projects:", error);
        }
      };
      fetchData();
    }
  }, [user?.id]);

  if (!userWithProjects) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>Welcome, {userWithProjects.firstName}!</h1>
      <h2>Your Projects:</h2>
      <ul>
        {userWithProjects.projects.map((project) => (
          <li key={project.id}>
            <h3>{project.name}</h3>
            <p>{project.description}</p>
            {project.imageUrl && <img src={project.imageUrl} alt={project.name} />}
            {project.price && <p>Price: ${project.price}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProjectListing;