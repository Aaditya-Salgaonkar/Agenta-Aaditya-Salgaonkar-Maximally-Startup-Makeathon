typescript
// SettingsPage.tsx

import React from 'react';
import { useForm } from 'react-hook-form';
import { useHistory } from 'react-router-dom';
import clerkClient from 'clerk-sdk';

interface SettingsPageProps {}

interface SettingsFormData {
  firstName?: string;
  lastName?: string;
  email?: string;
  username?: string;
  bio?: string;
  website?: string;
}

const SettingsPage: React.FC<SettingsPageProps> = () => {
  const history = useHistory();
  const { register, handleSubmit, errors } = useForm<SettingsFormData>();

  const onSubmit = handleSubmit(async (data) => {
    try {
      const user = await clerkClient.users.updateUser({
        userID: clerkClient.getUser().id,
        ...data,
      });

      // Handle successful update
      console.log('User updated:', user);
      history.push('/settings');
    } catch (err) {
      console.error('Error updating user:', err);
    }
  });

  return (
    <div>
      <h1>Update Profile</h1>
      <form onSubmit={onSubmit}>
        <label htmlFor="firstName">First Name</label>
        <input
          type="text"
          name="firstName"
          ref={register({ required: 'First name is required' })}
        />
        {errors.firstName && <p>{errors.firstName.message}</p>}

        <label htmlFor="lastName">Last Name</label>
        <input
          type="text"
          name="lastName"
          ref={register({ required: 'Last name is required' })}
        />
        {errors.lastName && <p>{errors.lastName.message}</p>}

        <label htmlFor="email">Email</label>
        <input type="email" name="email" ref={register({ required: 'Email is required' })} />
        {errors.email && <p>{errors.email.message}</p>}

        <label htmlFor="username">Username</label>
        <input type="text" name="username" ref={register({ required: 'Username is required' })} />
        {errors.username && <p>{errors.username.message}</p>}

        <label htmlFor="bio">Bio</label>
        <textarea name="bio" ref={register} />

        <label htmlFor="website">Website</label>
        <input type="url" name="website" ref={register} />

        <button type="submit">Update Profile</button>
      </form>
    </div>
  );
};

export default SettingsPage;