typescript
// SignIn.tsx

import { useUser } from "@clerk/clerk-react";
import React from "react";

interface SignInProps {}

const SignIn: React.FC<SignInProps> = () => {
  const { isSignedIn, signIn, user } = useUser();

  if (isSignedIn) {
    return <div>Welcome, {user.fullName}!</div>;
  }

  return (
    <div>
      <button onClick={() => signIn()}>Sign In</button>
    </div>
  );
};

export default SignIn;

// main.tsx

import React from "react";
import ReactDOM from "react-dom";
import { ClerkProvider } from "@clerk/clerk-react";
import SignIn from "./SignIn";

const frontendApi = "";

ReactDOM.render(
  <ClerkProvider frontendApi={frontendApi}>
    <SignIn />
  </ClerkProvider>,
  document.getElementById("root")
);