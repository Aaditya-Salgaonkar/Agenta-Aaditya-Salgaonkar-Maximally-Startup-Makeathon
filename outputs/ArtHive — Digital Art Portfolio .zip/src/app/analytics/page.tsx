typescript
// Dashboard.tsx

import React from 'react';
import { Bar, Line } from 'react-chartjs-2';
import 'chart.js/auto';

interface DashboardProps {
  salesData: {
    label: string;
    value: number;
  }[];
  trafficData: {
    label: string;
    data: number[];
  }[];
}

const Dashboard: React.FC<DashboardProps> = ({ salesData, trafficData }) => {
  const barChartOptions = {
    plugins: {
      title: {
        display: true,
        text: 'Sales by Product',
      },
    },
    responsive: true,
    scales: {
      y: {
        beginAtZero: true,
      },
    },
  };

  const lineChartOptions = {
    plugins: {
      title: {
        display: true,
        text: 'Traffic Over Time',
      },
    },
    responsive: true,
  };

  return (
    <div>
      <h1>Dashboard</h1>
      <div style={{ display: 'flex', justifyContent: 'space-around' }}>
        <div style={{ width: '45%' }}>
          <Bar data={{ labels: salesData.map((item) => item.label), datasets: [{ label: 'Sales', data: salesData.map((item) => item.value) }] }} options={barChartOptions} />
        </div>
        <div style={{ width: '45%' }}>
          <Line data={trafficData} options={lineChartOptions} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;