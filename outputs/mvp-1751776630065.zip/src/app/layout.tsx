npm install @clerk/clerk-react @next/font
# or
yarn add @clerk/clerk-react @next/font